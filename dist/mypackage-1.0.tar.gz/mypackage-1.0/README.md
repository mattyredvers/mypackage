# mypackage 
This librbary was created as an example for my python course to become a data scientist

# How to install
Instructions